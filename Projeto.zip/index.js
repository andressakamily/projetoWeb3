const express = require('express');
const res = require('express/lib/response');
const app = express();
app.set("view engine", "ejs");
app.use(express.urlencoded({extended: true}));
app.use(express.static ("public"));

const clienteRoutes = require("./routes/ClienteRoutes");
app.use(clienteRoutes);


const mongoose = require("mongoose");
mongoose.connect("mongodb+srv://kamily:kamily123@cluster0.t1ndtz3.mongodb.net/?retryWrites=true&w=majority");
const ClienteModel = require("./models/ClienteModel");


app.get("/", function(req, res){
    res.render("index");
});

app.use(function(req, res) {
   res.status(404).render("404");
});

app.listen("999", function(){
   console.log("Servidor iniciando");  
});