const ClienteModel = require("../models/ClienteModel");


class ClienteController{
    static async cadastrar(req, res){
        const novoCliente = new ClienteModel({
        id: req.body.id,
        nome: req.body.nome,
        idade: req.body.idade
      });
      await novoCliente.save();
        res.redirect("/clientes?s=1");
    }

    static cadastrarGet(req, res){
        res.render("cliente/cadastrar");
    }

    static async listar(req, res){
        const status = req.query.s;
        const vetorClientes = await ClienteModel.find();
        res.render("cliente/relatorio", {vetorClientes, status});
    }

    static async detalhar(req, res){
        const cliente = await ClienteModel.findOne({id: req.params.id});
        res.render("cliente/detalhar", {cliente});
    }
    static async remover(req, res){
        await ClienteModel.findOneAndDelete({id: req.params.id});
        res.redirect("/clientes?s=2");
    }

}

module.exports = ClienteController;